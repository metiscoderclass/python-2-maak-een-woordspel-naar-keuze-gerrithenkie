# print welkom
# vraag naam
# bedenk geheim woord van 5 letters

# loop totdat het geraden is of 5 keer
  # vraag gast om het geheime woord van 5 letters te gokken
  #als te weinig of teveel letters, dan 
  #  foutmelding
  #anders:  
    # kijk welke letters van de gok overeen kommen met het geheime woord
    # als letter van gok gelijk is aan de letter van geheim letter is goed 
    # anders letter van gok in geheim voorkomt letter is ? 
    # anders letter is _
  # als  antwoord = input print je hebt gewonnen wil je nog een keer?
    # als antwoord gelijk is aan ja
      # het hele programma begint opnieuw
    # als antwoord gelijk is aan nee 
      # stop hele programma
def begin():
  import random
  woordlijst = ["vogel", "adder", "druif", "woord", "onder", "ander", "kaars", "kwaad", "extra", "check", "drijf", "jemig", "relax", "uitje", "schip", "schub", "quads", "schel", "zacht", "kinky", "olijf", "richt", "vezel"]
  woord = random.choice(woordlijst)
  naam = input("Wat is jouw naam? ")
  print("Welkom " + naam)
  print("Dit is een Wordmind " + naam + " en je mag 5 keer een woord met 5 letters raden. ")

  def einde():
    antwoord = input("Wil je nog een keer? ")
    if antwoord == "ja":
      begin()
    elif antwoord == "nee":
      print("Oké bye bye")
      exit()
    else:
      einde()

  for i in range(5):
    gok = input("Gok het geheime woord! ")
    if len(gok) != len(woord):
      print("Type een woord met 5 letters! ")
    elif gok == woord:
      print("Gefeliciteerd je hebt het woord geraden ")
      einde()
    elif gok != woord:
      for positie, letter in enumerate(gok):
        if letter == woord[positie]:
          print(letter, end="")
        elif letter not in woord:
          print("-", end="")
        else:
          print("?", end="")
      print("")
  
  print("Helaas je hebt het geheime woord niet geraden. ")
  print("Het geheime woord was ")
  print(woord)
  einde()

begin()